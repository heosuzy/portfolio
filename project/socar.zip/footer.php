        <div id="footer_content">
            <p id="footer_logo"><img src="./img/fix_logo.gif" alt="f_logo"></p>
            <ul id="download">
                <li>관리자페이지</li>
                <li><a href="http://hsj1021.dothome.co.kr/myadmin ">hsj1021.dothome.co.kr/myadmin</a></li>
            </ul>
            <ul id="author">
                <li>문의 메일</li>
                <li>- 메일 주소 : ssujii0809@naver.com</li>
            </ul>
        </div>