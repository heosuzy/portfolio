<?php
    define('DBhost', 'hsj1021.dothome.co.kr');
    define('DBuser', 'hsj1021');  
    define('DBpass', 'gjtnwl90!!'); 
    define('DBname', 'hsj1021'); 
?>