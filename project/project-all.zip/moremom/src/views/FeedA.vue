<template>
  <body>
    <div id="writing_container">
      <svg class="writing_icon" width="104" height="104" viewBox="0 0 104 104" fill="none" xmlns="http://www.w3.org/2000/svg">
        <g filter="url(#filter0_d_76_1681)">
          <circle cx="52" cy="42" r="30" fill="url(#paint0_linear_76_1681)" />
        </g>
        <path d="M53.7471 50.4428H60.9997" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path fill-rule="evenodd" clip-rule="evenodd" d="M52.78 33.7948C53.5557 32.8678 54.95 32.7319 55.8962 33.4917C55.9485 33.533 57.6295 34.8388 57.6295 34.8388C58.669 35.4672 58.992 36.8031 58.3494 37.8226C58.3153 37.8772 48.8119 49.7645 48.8119 49.7645C48.4958 50.1589 48.0158 50.3918 47.5029 50.3973L43.8635 50.443L43.0435 46.9723C42.9287 46.4843 43.0435 45.9718 43.3597 45.5773L52.78 33.7948Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M51.0205 36.001L56.4728 40.1881" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
        <defs>
          <filter id="filter0_d_76_1681" x="0" y="0" width="104" height="104" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dy="10" />
            <feGaussianBlur stdDeviation="11" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.584314 0 0 0 0 0.678431 0 0 0 0 0.996078 0 0 0 0.3 0" />
            <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_76_1681" />
            <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_76_1681" result="shape" />
          </filter>
          <linearGradient id="paint0_linear_76_1681" x1="22" y1="12" x2="84.0951" y2="14.2529" gradientUnits="userSpaceOnUse">
            <stop stop-color="#FF416C" />
            <stop offset="1" stop-color="#FF4B2B" />
          </linearGradient>
        </defs>
      </svg>
    </div>

    <header id="header">
      <h1>커뮤니티</h1>
      <div class="header_container">
        <ul class="header_flex_container">
          <li><a href="#">커뮤니티</a></li>
          <li>
            <a class="search_icon txtnone" href="#">검색</a>
          </li>
          <li>
            <a class="alarm_icon txtnone" href="#">알람</a>
          </li>
        </ul>
      </div>
    </header>

    <nav id="nav">
      <div class="nav_container">
        <ul class="nav_flex_container">
          <li><a href="#">#카테고리1</a></li>
          <li><a href="#">#카테고리2</a></li>
          <li><a href="#">#카테고리3</a></li>
          <li><a href="#">#카테고리4</a></li>
          <li><a href="#">#카테고리5</a></li>
        </ul>
      </div>
    </nav>

    <main id="main">
      <div class="main_container">
        <ul class="main_contents">
          <li class="main_contents_li">
            <ul>
              <li class="title_menu"><a href="#">#카테고리1</a></li>
              <li class="menu_content"><a href="#">오늘 뭐 먹을까요?</a></li>
              <li class="good_bt"><button>좋아요 10</button></li>
              <li class="comment_bt"><button>댓글 0</button></li>
            </ul>
          </li>

          <li class="main_contents_li">
            <ul>
              <li class="title_menu"><a href="#">#카테고리1</a></li>
              <li class="menu_content"><a href="#">오늘 뭐 먹을까요?</a></li>
              <li class="good_bt"><button>좋아요 10</button></li>
              <li class="comment_bt"><button>댓글 0</button></li>
            </ul>
          </li>

          <li class="main_contents_li">
            <ul>
              <li class="title_menu"><a href="#">#카테고리1</a></li>
              <li class="menu_content"><a href="#">오늘 뭐 먹을까요?</a></li>
              <li class="good_bt"><button>좋아요 10</button></li>
              <li class="comment_bt"><button>댓글 0</button></li>
            </ul>
          </li>

          <li class="main_contents_li">
            <ul>
              <li class="title_menu"><a href="#">#카테고리1</a></li>
              <li class="menu_content"><a href="#">오늘 뭐 먹을까요?</a></li>
              <li class="good_bt"><button>좋아요 10</button></li>
              <li class="comment_bt"><button>댓글 0</button></li>
            </ul>
          </li>

          <li class="main_contents_li">
            <ul>
              <li class="title_menu"><a href="#">#카테고리1</a></li>
              <li class="menu_content"><a href="#">오늘 뭐 먹을까요?</a></li>
              <li class="good_bt"><button>좋아요 10</button></li>
              <li class="comment_bt"><button>댓글 0</button></li>
            </ul>
          </li>

          <li class="main_contents_li">
            <ul>
              <li class="title_menu"><a href="#">#카테고리1</a></li>
              <li class="menu_content"><a href="#">오늘 뭐 먹을까요?</a></li>
              <li class="good_bt"><button>좋아요 10</button></li>
              <li class="comment_bt"><button>댓글 0</button></li>
            </ul>
          </li>

          <li class="main_contents_li">
            <ul>
              <li class="title_menu"><a href="#">#카테고리1</a></li>
              <li class="menu_content"><a href="#">오늘 뭐 먹을까요?</a></li>
              <li class="good_bt"><button>좋아요 10</button></li>
              <li class="comment_bt"><button>댓글 0</button></li>
            </ul>
          </li>

          <li class="main_contents_li">
            <ul>
              <li class="title_menu"><a href="#">#카테고리1</a></li>
              <li class="menu_content"><a href="#">오늘 뭐 먹을까요?</a></li>
              <li class="good_bt"><button>좋아요 10</button></li>
              <li class="comment_bt"><button>댓글 0</button></li>
            </ul>
          </li>

          <li class="main_contents_li">
            <ul>
              <li class="title_menu"><a href="#">#카테고리1</a></li>
              <li class="menu_content"><a href="#">오늘 뭐 먹을까요?</a></li>
              <li class="good_bt"><button>좋아요 10</button></li>
              <li class="comment_bt"><button>댓글 0</button></li>
            </ul>
          </li>
        </ul>
      </div>
    </main>

    <footer id="footer">
      <div class="foot_container">
        <div class="foot_flex_svg">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M9.15722 20.7714V17.7047C9.1572 16.9246 9.79312 16.2908 10.581 16.2856H13.4671C14.2587 16.2856 14.9005 16.9209 14.9005 17.7047V20.7809C14.9003 21.4432 15.4343 21.9845 16.103 22H18.0271C19.9451 22 21.5 20.4607 21.5 18.5618V9.83784C21.4898 9.09083 21.1355 8.38935 20.538 7.93303L13.9577 2.6853C12.8049 1.77157 11.1662 1.77157 10.0134 2.6853L3.46203 7.94256C2.86226 8.39702 2.50739 9.09967 2.5 9.84736V18.5618C2.5 20.4607 4.05488 22 5.97291 22H7.89696C8.58235 22 9.13797 21.4499 9.13797 20.7714" fill="url(#paint0_linear_93_1181)" />
            <defs>
              <linearGradient id="paint0_linear_93_1181" x1="2.5" y1="2" x2="22.166" y2="2.67783" gradientUnits="userSpaceOnUse">
                <stop stop-color="#FF416C" />
                <stop offset="1" stop-color="#FF4B2B" />
              </linearGradient>
            </defs>
          </svg>

          <svg width="22" height="18" viewBox="0 0 22 18" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M16.8877 7.89673C18.2827 7.70073 19.3567 6.50473 19.3597 5.05573C19.3597 3.62773 18.3187 2.44373 16.9537 2.21973" stroke="#ADA4A5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M18.7285 11.25C20.0795 11.452 21.0225 11.925 21.0225 12.9C21.0225 13.571 20.5785 14.007 19.8605 14.281" stroke="#ADA4A5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            <path fill-rule="evenodd" clip-rule="evenodd" d="M10.8867 11.6641C7.67273 11.6641 4.92773 12.1511 4.92773 14.0961C4.92773 16.0401 7.65573 16.5411 10.8867 16.5411C14.1007 16.5411 16.8447 16.0591 16.8447 14.1131C16.8447 12.1671 14.1177 11.6641 10.8867 11.6641Z" stroke="#ADA4A5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            <path fill-rule="evenodd" clip-rule="evenodd" d="M10.8864 8.888C12.9954 8.888 14.7054 7.179 14.7054 5.069C14.7054 2.96 12.9954 1.25 10.8864 1.25C8.77741 1.25 7.06741 2.96 7.06741 5.069C7.05941 7.171 8.75641 8.881 10.8584 8.888H10.8864Z" stroke="#ADA4A5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M4.88509 7.89673C3.48909 7.70073 2.41609 6.50473 2.41309 5.05573C2.41309 3.62773 3.45409 2.44373 4.81909 2.21973" stroke="#ADA4A5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M3.044 11.25C1.693 11.452 0.75 11.925 0.75 12.9C0.75 13.571 1.194 14.007 1.912 14.281" stroke="#ADA4A5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
          </svg>

          <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M18.0714 18.0699C15.0152 21.1263 10.4898 21.7867 6.78642 20.074C6.23971 19.8539 5.79148 19.676 5.36537 19.676C4.17849 19.683 2.70117 20.8339 1.93336 20.067C1.16555 19.2991 2.31726 17.8206 2.31726 16.6266C2.31726 16.2004 2.14642 15.7602 1.92632 15.2124C0.212831 11.5096 0.874109 6.98269 3.93026 3.92721C7.8316 0.0244319 14.17 0.0244322 18.0714 3.9262C21.9797 7.83501 21.9727 14.1681 18.0714 18.0699Z" stroke="#ADA4A5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M14.9398 11.4131H14.9488" stroke="#ADA4A5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M10.9301 11.4131H10.9391" stroke="#ADA4A5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M6.92128 11.4131H6.93028" stroke="#ADA4A5" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
          </svg>

          <svg width="16" height="20" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M7.98493 13.3457C4.11731 13.3457 0.814453 13.9305 0.814453 16.2724C0.814453 18.6143 4.09636 19.22 7.98493 19.22C11.8525 19.22 15.1545 18.6343 15.1545 16.2933C15.1545 13.9524 11.8735 13.3457 7.98493 13.3457Z" stroke="#ADA4A5" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
            <path fill-rule="evenodd" clip-rule="evenodd" d="M7.98489 10.0059C10.523 10.0059 12.5801 7.94779 12.5801 5.40969C12.5801 2.8716 10.523 0.814453 7.98489 0.814453C5.44679 0.814453 3.3887 2.8716 3.3887 5.40969C3.38013 7.93922 5.42394 9.99731 7.95251 10.0059H7.98489Z" stroke="#ADA4A5" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
          </svg>
        </div>
      </div>
    </footer>
  </body>
</template>

<script>
  export default {
    name: 'App',
    components: {},
  };
</script>

<style scoped>
  @import '../css/reset.css';

  html,
  body {
    width: 100%;
    margin: 0 auto;
    font-family: 'Noto Sans KR', sans-serif;
  }

  ul,
  li {
    list-style: none;
  }

  a {
    text-decoration: none;
    color: black;
  }

  h1 {
    display: none;
  }

  button {
    background: inherit;
    border: none;
    box-shadow: none;
    border-radius: 0;
    padding: 0;
    overflow: visible;
    cursor: pointer;
    color: #ff6060;
    font-size: 0.688em;
  }

  #writing_container {
    position: fixed;
    right: 2%;
    bottom: 7%;
    z-index: 2;
    width: 104px;
    height: 104px;
    margin: 0 auto;
    cursor: pointer;
  }

  /* 헤더 */
  #header .header_container {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 2;
    width: 100%;
    margin: 0 auto;
    background-color: #ffffff;
  }
  #header .header_container .header_flex_container {
    width: 100%;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  #header .header_container .header_flex_container > li {
    text-align: center;
  }

  #header .header_container .header_flex_container > li:first-child {
    flex: 1 1 80%;
  }
  #header .header_container .header_flex_container > li:first-child > a {
    padding-left: 25%;
    color: #1d1617;
    font-size: 1em;
    font-weight: 600;
  }
  #header .header_container .header_flex_container > li:nth-child(n + 2) {
    flex: 1 1 9%;
  }
  #header .header_container .header_flex_container > li:last-child {
    padding-right: 2%;
  }
  #header .header_container .header_flex_container > li > a.txtnone {
    display: block;
    text-indent: -9999px;
  }
  #header .header_container .header_flex_container > li > a.search_icon {
    background: url(../assets/search_icon.png) no-repeat center;
    background-size: contain;
  }
  #header .header_container .header_flex_container > li > a.alarm_icon {
    background: url(../assets/alarm_icon.png) no-repeat center;
    background-size: contain;
  }

  /* 네비 */
  #nav .nav_container {
    width: 100%;
    margin: 0 auto;
    margin-top: 100px;
    background-color: #f5f5f5;
    border-top: 1px solid #e9e9e9;
    border-bottom: 1px solid #e9e9e9;
    box-sizing: border-box;
  }

  #nav .nav_container .nav_flex_container {
    width: 100%;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-around;
  }

  #nav .nav_container .nav_flex_container > li > a {
    display: block;
    padding: 5px;
    font-size: 0.625rem;
  }
  #nav .nav_container .nav_flex_container > li > a:hover {
    border: 1px solid #563434;
    box-sizing: border-box;
    border-radius: 19px;
  }

  /* 메인 */
  #main .main_container {
    width: 100%;
    height: 100%;
    background-color: #ffffff;
  }
  #main .main_container .main_contents {
    width: 90%;
    margin: 0 auto;
  }
  #main .main_container .main_contents .main_contents_li {
    width: 100%;
    height: 95px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 5px;
    background-color: #f7f8f8;
    margin-top: 16px;
  }
  #main .main_container .main_contents .main_contents_li > ul {
    width: 100%;
  }
  #main .main_container .main_contents .main_contents_li > ul li.title_menu {
    width: 60px;
    height: 20px;
    background-color: #ada4a5;
    border-radius: 5px;
    margin: 5px;
  }
  #main .main_container .main_contents .main_contents_li > ul li.title_menu > a {
    display: block;
    line-height: 20px;
    color: #ffffff;
    font-size: 0.625em;
    text-align: center;
  }
  #main .main_container .main_contents .main_contents_li > ul li.menu_content {
    width: 100%;
    margin: 10px 5px;
  }
  #main .main_container .main_contents .main_contents_li > ul li.menu_content > a {
    display: block;
    color: #000000;
    font-size: 0.75em;
  }
  #main .main_container .main_contents .main_contents_li > ul > li:nth-child(n + 3) {
    float: left;
    margin: 10px 5px;
  }

  /* 푸터 */
  #footer .foot_container {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    margin: 0 auto;
    background-color: #ffffff;
  }

  #footer .foot_container .foot_flex_svg {
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: space-around;
  }
  #footer .foot_container .foot_flex_svg > svg {
    cursor: pointer;
  }
</style>
